# A designer's code of ethics
(Mike Monteiro, Jul 6, 2017 - [URL](https://deardesignstudent.com/a-designers-code-of-ethics-f4a88aca9e95))

## A designer is first and foremost a human being.

Before you are a designer, you are a human being. Like every other human being on the planet, you are part of the social contract. We share a planet. By choosing to be a designer you are choosing to impact the people who come in contact with your work, you can either help or hurt them with your actions. The effect of what you put into the fabric of society should always be a key consideration in your work.

Every human being on this planet is obligated to do our best to leave this planet in better shape than we found it. Designers don’t get to opt out.

When you do work that depends on a need for income disparity or class distinctions to succeed you are failing your job as a citizen, and therefore as a designer.

## A designer is responsible for the work they put into the world.

Design is a discipline of action. You are responsible for what you put into the world. It has your name on it. And while it is certainly impossible to predict how any of your work may be used, it shouldn’t be a surprise when work that is meant to hurt someone fulfills its mission. We cannot be surprised when a gun we designed kills someone. We cannot be surprised when a database we designed to catalog immigrants gets those immigrants deported. When we knowingly produce work that is intended to harm, we are abdicating our responsibility. When we ignorantly produce work that harms others because we didn’t consider the full ramifications of that work, we are doubly guilty.

The work you bring into the world is your legacy. It will outlive you. And it will speak for you.

## A designer values impact over form.

We need to fear the consequences of our work more than we love the cleverness of our ideas.

Design does not exist in a vacuum. Society is the biggest system we can impact and everything you do is a part of that system, good and bad. Ultimately we must judge the value of our work based on that impact, rather than any aesthetic considerations. An object that is designed to harm people cannot be said to be well-designed, no matter how aesthetically pleasing it might be, because to design it well is to design it to harm others. Nothing a totalitarian regime designs is well-designed because it has been designed by a totalitarian regime.

> A broken gun is better designed than a working gun.

![Non-Violence, Carl Fredrik Reuterswärd, 1985](broken-gun.webp)

## A designer owes the people who hire them not just their labor, but their counsel.

When you are hired to design something, you are hired for your expertise. Your job is not just to produce that work but to evaluate the impact of that work. Your job is to relay the impact of that work to your client or employer. And should that impact be negative, it is your job to relay that to your client along with a way, if possible, to eliminate the negative impact of the work. If it’s impossible to eliminate the negative impact of the work, it’s your job to stop it from seeing the light of day. In other words, you’re not hired to just dig a ditch, but to evaluate the economic, sociological, and ecological impact of that ditch. If the ditch fails those tests, it’s your job to destroy the shovels.

A designer uses their expertise in the service of others without being a servant. Saying no is a design skill. Asking why is a design skill. Rolling your eyes is not. Asking ourselves why we are making something is an infinitely better question than asking ourselves whether we can make it.

## A designer welcomes criticism.

No code of ethics should protect your work from criticism, be it from clients, the public, or other designers. Instead, you should encourage criticism in order to create better work in the future. If your work is so fragile that it can’t withstand criticism it shouldn’t exist. The time to kick the tires on your work comes before those tires hit the road. And be open to that criticism coming from anywhere.

The role of criticism, when given appropriately, is to evaluate and improve work. Criticism is a gift. It makes good work better. It keeps bad work from seeing the light of day.

Criticism should be asked for and welcomed at every step of the design process. You can’t fix a cake once it’s been baked. But you can increase the chances your project is successful by getting feedback early and often. It’s your responsibility to ask for criticism.

## A designer strives to know their audience.

Design is the intentional solution to a problem within a set of constraints. To know whether you are properly solving those problems you need to meet the people who are having them. And if you are part of a team, your team should strive to reflect those people. The more a team can reflect the audience it is solving for, the more thoroughly it can solve those problems. That team can come at a problem from different points-of-view, from different backgrounds, from different sets of needs and experiences. A team with a single point of view will never understand the constraints they need to design for as well as a team with multiple points of view.

What about empathy? Empathy is a pretty word for exclusion. If you want to know how women would use something you’re designing get a woman on the team that’s designing it.

## A designer does not believe in edge cases.

When you decide who you’re designing for, you’re making an implicit statement about who you’re not designing for. For years we referred to people who weren’t crucial to our products’ success as “edge cases”. We were marginalizing people. And we were making a decision that there were people in the world whose problems weren’t worth solving.

Facebook now claims to have two billion users. 1% of two billion people, which most products would consider an edge case, is twenty million people. Those are the people at the margins.

> “When you call something an edge case, you’re really just defining the limits of what you care about.” — Eric Meyer

These are the trans people who get caught on the edges of “real names” projects. These are the single moms who get caught on the edges of “both parents must sign” permission slips. These are the elderly immigrants who show up to vote and can’t get ballots in their native tongues.

They are not edge cases. They are human beings, and we owe them our best work.
Press enter or click to view image in full size
dottie-lux.webp

![This is Dottie Lux. She fights Facebook to help trans people and drag queens get the username they want.](dottie-lux.webp)

## A designer is part of a professional community.

You are part of a professional community and the way you do your job and handle yourself professionally affects everyone in that community. Just as a rising tide affects all boats, taking a shit in the pool affects all swimmers. If you are dishonest with a client or employer, the designer behind you will pay the price. If you work for free, the designer behind you will be expected to do the same. If you do not hold your ground on doing bad work, the designer behind you will have to work twice as hard to make up for it.

While a designer has an ethical obligation to earn a living to the best of their abilities and opportunities, doing it at the expense of others who share the craft is a disservice to us all. Never throw another designer under the bus to advance your own agenda. This includes public redesigns of someone else’s work, spec work, unsolicited work, and plagiarism.

> A designer seeks to build the community, not divide it.

## A designer welcomes a diverse and competitive field.

Throughout their entire career, a designer seeks to learn. That means confronting what they do not know. That means listening to other people’s experiences. That means welcoming and encouraging people who come from diverse backgrounds, diverse cultures. That means making space at the table for people who society has historically kept down. We must make space for traditionally marginalized voices to be heard in the profession. Diversity leads to better outcomes and solutions. Diversity leads to better design.

> “You’ll never go wrong when you work with someone smarter than you.” — Tibor Kalman

A designer keeps their ego in check, knows when to shut up and listen, is aware of their own biases and welcomes having them checked, and fights to make room for those who have been silenced.

## A designer takes time for self-reflection.

No one wakes up one day designing to throw their ethics out the window. It happens slowly, one slippery slope at a time. It’s a series of small decisions that might even seem fine at the time, and before you know it you’re designing filtering UI for the Walmart online gun shop.

Take the time for self-reflection every few months. Evaluate the decisions you’ve made recently. Are you staying true to who you are? Or are you slowly moving your ethical goal posts a few yards at a time with each raise or stock option award?

Have you veered off course? Correct it. Is your workplace an unethical hellmouth? Get another one.

Your job is a choice. Please do it right.

————————

Mike Monteiro is a nice guy or a total asshole depending on your opinion. He is also the Design Director at Mule Design. And the author of Design Is a Job and You’re My Favorite Client.

Thanks to Ross Floate, John Hanawalt, Greg Storey, Kio Stark, and Sean Bonner for helping with this piece. BTW, I’ll probably keep updating this as people come up with things I forgot.

————————

FYI: [MarkDown Guide](https://www.markdownguide.org/)